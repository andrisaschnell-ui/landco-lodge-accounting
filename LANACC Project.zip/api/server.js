// LANACC local API: auth (login) + generic CRUD over whitelisted tables.
// Replaces Supabase for the on-premise Docker deployment.

import express from "express";
import cors from "cors";
import pkg from "pg";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const { Pool } = pkg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const JWT = process.env.JWT_SECRET || "dev-secret";

const app = express();
app.use(cors());
app.use(express.json({ limit: "20mb" }));

// ---------- helpers ----------
const TABLES = new Set([
  "properties","shareholders","bank_accounts","expense_categories",
  "employees","exchange_rates","income_transactions","expense_transactions",
  "bank_transactions","petty_cash_transactions","salary_runs","salary_lines",
  "salary_advances","bim_salary_transfers","inss_payments","irps_payments",
  "shareholder_balances","import_log","profiles","user_roles",
]);

function requireAuth(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return res.status(401).json({ error: "missing token" });
  try { req.user = jwt.verify(token, JWT); next(); }
  catch { return res.status(401).json({ error: "invalid token" }); }
}

// ---------- auth ----------
app.post("/auth/login", async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: "email/password required" });
  const { rows } = await pool.query("SELECT id,email,password_hash,display_name FROM auth.users WHERE email=$1",[email]);
  const u = rows[0];
  if (!u || !bcrypt.compareSync(password, u.password_hash))
    return res.status(401).json({ error: "invalid credentials" });
  const { rows: rr } = await pool.query("SELECT role FROM public.user_roles WHERE user_id=$1",[u.id]);
  const roles = rr.map(r => r.role);
  const token = jwt.sign({ sub: u.id, email: u.email, roles }, JWT, { expiresIn: "12h" });
  res.json({ token, user: { id: u.id, email: u.email, display_name: u.display_name, roles } });
});

app.get("/auth/me", requireAuth, (req, res) => res.json({ user: req.user }));

// ---------- generic table API ----------
app.get("/api/:table", requireAuth, async (req, res) => {
  const t = req.params.table;
  if (!TABLES.has(t)) return res.status(404).json({ error: "unknown table" });
  const limit = Math.min(parseInt(req.query.limit) || 1000, 5000);
  try {
    const { rows } = await pool.query(`SELECT * FROM public.${t} LIMIT $1`,[limit]);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/:table", requireAuth, async (req, res) => {
  const t = req.params.table;
  if (!TABLES.has(t)) return res.status(404).json({ error: "unknown table" });
  if (!req.user.roles?.includes("admin")) return res.status(403).json({ error: "admin only" });
  const body = req.body || {};
  const cols = Object.keys(body);
  if (!cols.length) return res.status(400).json({ error: "empty body" });
  const params = cols.map((_, i) => `$${i + 1}`);
  try {
    const { rows } = await pool.query(
      `INSERT INTO public.${t} (${cols.join(",")}) VALUES (${params.join(",")}) RETURNING *`,
      cols.map(c => body[c])
    );
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get("/health", (_, res) => res.json({ ok: true }));

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`LANACC API listening on :${port}`));
