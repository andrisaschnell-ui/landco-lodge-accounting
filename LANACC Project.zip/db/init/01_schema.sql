-- ============================================================
-- LANACC — Landco Lodge Accounting — PostgreSQL schema
-- Mirrors the Lovable Cloud (Supabase) schema for local Docker
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ----- ENUMS -----
DO $$ BEGIN
  CREATE TYPE public.app_role AS ENUM ('admin','viewer');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ----- AUTH (lightweight local replacement for Supabase auth) -----
CREATE SCHEMA IF NOT EXISTS auth;

CREATE TABLE IF NOT EXISTS auth.users (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email         text UNIQUE NOT NULL,
  password_hash text NOT NULL,                       -- bcrypt hash
  display_name  text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- ----- CORE TABLES -----
CREATE TABLE IF NOT EXISTS public.profiles (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL UNIQUE,
  email        text,
  display_name text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.user_roles (
  id      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  role    public.app_role NOT NULL,
  UNIQUE (user_id, role)
);

CREATE TABLE IF NOT EXISTS public.properties (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code        text NOT NULL UNIQUE,
  name        text NOT NULL,
  description text,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.shareholders (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name                 text NOT NULL,
  email                text,
  property_code        text REFERENCES public.properties(code),
  ownership_percentage numeric,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bank_accounts (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name           text NOT NULL,
  bank_name      text NOT NULL,
  account_number text,
  currency       text NOT NULL DEFAULT 'MZN',
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.expense_categories (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name       text NOT NULL,
  is_shared  boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.employees (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name             text NOT NULL,
  category         text,
  nib              text,
  nuit             text,
  base_salary      numeric NOT NULL DEFAULT 0,
  food_allowance   numeric DEFAULT 0,
  house_assignment text,
  is_active        boolean NOT NULL DEFAULT true,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.exchange_rates (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  month        integer NOT NULL,
  year         integer NOT NULL,
  mzn_per_usd  numeric NOT NULL,
  mzn_per_zar  numeric,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (month, year)
);

CREATE TABLE IF NOT EXISTS public.income_transactions (
  id                       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id              uuid REFERENCES public.properties(id),
  date                     date NOT NULL,
  guest_name               text,
  description              text,
  amount_usd               numeric DEFAULT 0,
  accommodation_amount_mzn numeric NOT NULL DEFAULT 0,
  month                    integer NOT NULL,
  year                     integer NOT NULL,
  created_at               timestamptz NOT NULL DEFAULT now(),
  updated_at               timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.expense_transactions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id     uuid REFERENCES public.properties(id),
  shareholder_id  uuid REFERENCES public.shareholders(id),
  category_id     uuid REFERENCES public.expense_categories(id),
  date            date,
  description     text NOT NULL,
  amount_mzn      numeric NOT NULL DEFAULT 0,
  is_shared       boolean NOT NULL DEFAULT true,
  month           integer NOT NULL,
  year            integer NOT NULL,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bank_transactions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bank_account_id uuid REFERENCES public.bank_accounts(id),
  date            date,
  description     text NOT NULL,
  reference       text,
  debit           numeric DEFAULT 0,
  credit          numeric DEFAULT 0,
  balance         numeric DEFAULT 0,
  month           integer NOT NULL,
  year            integer NOT NULL,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.petty_cash_transactions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date        date,
  description text NOT NULL,
  debit       numeric DEFAULT 0,
  credit      numeric DEFAULT 0,
  balance     numeric DEFAULT 0,
  month       integer NOT NULL,
  year        integer NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.salary_runs (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  month                integer NOT NULL,
  year                 integer NOT NULL,
  status               text NOT NULL DEFAULT 'draft',
  total_gross          numeric DEFAULT 0,
  total_net            numeric DEFAULT 0,
  total_irps           numeric DEFAULT 0,
  total_inss_employee  numeric DEFAULT 0,
  total_inss_employer  numeric DEFAULT 0,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.salary_lines (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salary_run_id       uuid NOT NULL REFERENCES public.salary_runs(id) ON DELETE CASCADE,
  employee_id         uuid NOT NULL REFERENCES public.employees(id),
  category            text,
  nib                 text,
  base_salary         numeric DEFAULT 0,
  food_allowance      numeric DEFAULT 0,
  monthly_salary      numeric DEFAULT 0,
  days_worked         integer DEFAULT 30,
  back_payment        numeric DEFAULT 0,
  nightshift_hours    numeric DEFAULT 0,
  guardas_25          numeric DEFAULT 0,
  overtime_25_percent numeric DEFAULT 0,
  overtime_15x_hours  numeric DEFAULT 0,
  overtime_15x_amount numeric DEFAULT 0,
  overtime_2x_hours   numeric DEFAULT 0,
  overtime_2x_amount  numeric DEFAULT 0,
  gratification       numeric DEFAULT 0,
  holiday_days        integer DEFAULT 0,
  holiday_amount      numeric DEFAULT 0,
  gross_total         numeric DEFAULT 0,
  inss_employee       numeric DEFAULT 0,
  irps                numeric DEFAULT 0,
  sind                numeric DEFAULT 0,
  advance             numeric DEFAULT 0,
  debt                numeric DEFAULT 0,
  total_deductions    numeric DEFAULT 0,
  net_salary          numeric DEFAULT 0,
  created_at          timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.salary_advances (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES public.employees(id),
  date        date NOT NULL,
  amount      numeric NOT NULL,
  description text,
  month       integer NOT NULL,
  year        integer NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bim_salary_transfers (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salary_run_id uuid REFERENCES public.salary_runs(id) ON DELETE CASCADE,
  employee_id   uuid REFERENCES public.employees(id),
  name          text NOT NULL,
  nib           text,
  amount        numeric NOT NULL,
  description   text,
  month         integer NOT NULL,
  year          integer NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.inss_payments (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  month        integer NOT NULL,
  year         integer NOT NULL,
  amount       numeric NOT NULL,
  payment_date date,
  reference    text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.irps_payments (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  month        integer NOT NULL,
  year         integer NOT NULL,
  amount       numeric NOT NULL,
  payment_date date,
  reference    text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.shareholder_balances (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shareholder_id  uuid NOT NULL REFERENCES public.shareholders(id),
  property_id     uuid NOT NULL REFERENCES public.properties(id),
  month           integer NOT NULL,
  year            integer NOT NULL,
  opening_balance numeric DEFAULT 0,
  income          numeric DEFAULT 0,
  expenses        numeric DEFAULT 0,
  closing_balance numeric DEFAULT 0,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.import_log (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  filename          text NOT NULL,
  file_type         text NOT NULL,
  month             integer,
  year              integer,
  records_imported  integer DEFAULT 0,
  status            text NOT NULL DEFAULT 'pending',
  error_details     text,
  imported_by       uuid,
  created_at        timestamptz NOT NULL DEFAULT now()
);

-- ----- INDEXES -----
CREATE INDEX IF NOT EXISTS idx_income_my   ON public.income_transactions(year, month);
CREATE INDEX IF NOT EXISTS idx_expense_my  ON public.expense_transactions(year, month);
CREATE INDEX IF NOT EXISTS idx_bank_my     ON public.bank_transactions(year, month);
CREATE INDEX IF NOT EXISTS idx_petty_my    ON public.petty_cash_transactions(year, month);
CREATE INDEX IF NOT EXISTS idx_salary_my   ON public.salary_runs(year, month);

-- ----- HELPER: has_role (mirrors Supabase) -----
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;
