-- Seed two admin users.
-- Password hashes are bcrypt of:
--   cwschnell@gmail.com        -> Abcd7654$
--   andrisa.schnell@gmail.com  -> Abcd7654#

INSERT INTO auth.users (id, email, password_hash, display_name)
VALUES
  ('11111111-1111-1111-1111-111111111111',
   'cwschnell@gmail.com',
   crypt('Abcd7654$', gen_salt('bf', 10)),
   'C.W. Schnell'),
  ('22222222-2222-2222-2222-222222222222',
   'andrisa.schnell@gmail.com',
   crypt('Abcd7654#', gen_salt('bf', 10)),
   'Andrisa Schnell')
ON CONFLICT (email) DO UPDATE
  SET password_hash = EXCLUDED.password_hash,
      display_name  = EXCLUDED.display_name;

INSERT INTO public.profiles (user_id, email, display_name)
SELECT id, email, display_name FROM auth.users
WHERE email IN ('cwschnell@gmail.com','andrisa.schnell@gmail.com')
ON CONFLICT (user_id) DO NOTHING;

INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::public.app_role FROM auth.users
WHERE email IN ('cwschnell@gmail.com','andrisa.schnell@gmail.com')
ON CONFLICT (user_id, role) DO NOTHING;
