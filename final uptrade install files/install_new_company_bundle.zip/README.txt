Landco Accounting — New-Company Installer Bundle
================================================

Files included:
  scripts/install-new-company.bat   Windows installer wizard
  scripts/install-new-company.sh    Mac/Linux installer wizard
  db/seed/demo_data.sql             Optional placeholder data (chart of
                                    accounts + sample property/shareholders)
  db/migrations/2026_add_company_telephone.sql
                                    Adds 'telephone' column to existing
                                    installs (already included automatically
                                    in the v5 schema for new installs)

To install a new company:
  Windows  -> double-click scripts/install-new-company.bat
  Mac/Linux -> chmod +x scripts/install-new-company.sh && ./scripts/install-new-company.sh

Full step-by-step end-user instructions are in:
  INSTALL_NEW_COMPANY_GUIDE.docx
