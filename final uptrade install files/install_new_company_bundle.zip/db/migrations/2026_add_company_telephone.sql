-- Adds telephone column to company_settings.
-- Run once on existing local installs:
--   docker exec lanacc-db psql -U postgres -d landco_v2_db -f /docker-entrypoint-initdb.d/2026_add_company_telephone.sql
ALTER TABLE public.company_settings
  ADD COLUMN IF NOT EXISTS telephone text;
